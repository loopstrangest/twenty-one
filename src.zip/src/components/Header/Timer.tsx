/** @format */

import React, { useState, useEffect } from "react";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import { Box } from "@mui/system";
import PlayArrowIcon from "@mui/icons-material/PlayArrow";
import PauseIcon from "@mui/icons-material/Pause";

interface TimerProps {
  currentTime: number;
  setCurrentTime: (time: number) => void;
}

const Timer: React.FC<TimerProps> = ({ currentTime, setCurrentTime }) => {
  const [isPaused, setIsPaused] = useState(false);

  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (!isPaused) {
      interval = setInterval(() => {
        setCurrentTime(currentTime + 1);
      }, 1000);
    } else if (isPaused && currentTime !== 0) {
      if (interval !== null) {
        clearInterval(interval);
      }
    }
    return () => {
      if (interval !== null) {
        clearInterval(interval);
      }
    };
  }, [isPaused, currentTime, setCurrentTime]);

  const handleButtonClick = () => {
    setIsPaused(!isPaused);
  };

  return (
    <Box
      sx={{ display: "flex", justifyContent: "center", alignItems: "center" }}
    >
      <Button disableRipple onClick={handleButtonClick}>
        {isPaused ? (
          <PlayArrowIcon className="icon-button" />
        ) : (
          <PauseIcon className="icon-button" />
        )}
      </Button>
      <Typography variant="h6">
        {String(Math.floor(currentTime / 60)).padStart(2, "0")}:
        {currentTime % 60 < 10 ? "0" : ""}
        {currentTime % 60}
      </Typography>
    </Box>
  );
};

export default Timer;
