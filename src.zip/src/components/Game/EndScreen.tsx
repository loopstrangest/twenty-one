/** @format */

import { Box, Typography } from "@mui/material";
import React, { useState } from "react";

interface EndScreenProps {
  gameNumber: number;
  shareObject: {
    rank: number;
    rankWithSuffixString: string;
    timeString: string;
    equation: (string | number | null)[];
  } | null;
  result: number;
}

const EndScreen: React.FC<EndScreenProps> = ({
  gameNumber,
  shareObject,
  result,
}) => {
  const [copied, setCopied] = useState(false);

  const handleShareClick = async () => {
    if (shareObject) {
      try {
        await navigator.clipboard.writeText(
          `🟢 Twenty One #${gameNumber} 🟢\n${shareObject.rankWithSuffixString} equation in ${shareObject.timeString}\nhttps://strangestloop.io/twenty-one`
        );
        setCopied(true);
      } catch (err) {
        console.error("Failed to copy text: ", err);
      }
    }
  };

  const rank = shareObject ? shareObject.rank : 0;
  const equation = shareObject ? shareObject.equation.join(" ") : "";
  return (
    <Box>
      <Typography my={1} sx={{ fontSize: "1.25em", fontWeight: "bold" }}>
        You found today's {shareObject?.rankWithSuffixString} equation!
      </Typography>
      <Typography my={1} sx={{ fontSize: "1.75em", fontWeight: "bold" }}>
        {equation} = {result}
      </Typography>
      {rank > 1 && (
        <>
          <Typography my={1} sx={{ fontSize: "1.25em", fontWeight: "bold" }}>
            Best equation:
          </Typography>
          <Typography my={1} sx={{ fontSize: "1.75em", fontWeight: "bold" }}>
            {equation} = {result}{" "}
          </Typography>
        </>
      )}
      <Typography my={1} sx={{ fontSize: "1.25em", fontWeight: "bold" }}>
        Come back tomorrow for a new game!
      </Typography>

      <button className="copy-button" onClick={handleShareClick}>
        {copied ? "Copied!" : "Share my score"}
      </button>
    </Box>
  );
};

export default EndScreen;
