/** @format */

import { Box } from "@mui/system";
import Numbers from "./Numbers";
import Operators from "./Operators";
import TwentyOneDisplay from "./TwentyOneDisplay";
import Equation from "./Equation";
import SubmitButton from "./SubmitButton";
import ClearButton from "./ClearButton";
import EndScreen from "./EndScreen";
import { useEffect, useState } from "react";
import Footer from "../Footer/Footer";
import { loadState, saveState } from "../../utils/localStorage";
import { calculateRank } from "../../utils/calculateRank";

interface GameProps {
  currentTime: number;
}

const Game: React.FC<GameProps> = ({ currentTime }) => {
  const [currentStreak, setCurrentStreak] = useState<number>(
    loadState("currentStreak") || 0
  );
  const [lastPlayedDate, setLastPlayedDate] = useState<string | null>(
    loadState("lastPlayedDate") || null
  );
  const [bestResults, setBestResults] = useState<
    Array<{ date: string; rank: number; time: number }>
  >(loadState("bestResults") || []);
  const [totalDaysPlayed, setTotalDaysPlayed] = useState<number>(
    loadState("totalDaysPlayed") || 0
  );
  const [longestStreak, setLongestStreak] = useState<number>(
    loadState("longestStreak") || 0
  );
  const [equationSubmitted, setEquationSubmitted] = useState<boolean>(false);
  const [evaluation, setEvaluation] = useState<number | null>(null);
  const [shareObject, setShareObject] = useState<{
    rank: number;
    rankWithSuffixString: string;
    timeString: string;
    equation: (string | number | null)[];
  } | null>(loadState("shareObject") || null);
  const offset = new Date().getTimezoneOffset() + 480; // 480 minutes = 8 hours behind UTC (PST)

  const today = new Date(new Date().getTime() - offset * 60 * 1000)
    .toISOString()
    .split("T")[0];

  const [equation, setEquation] = useState<(string | number | null)[]>(
    Array(7).fill(null)
  );
  const [numbers, setNumbers] = useState<
    Array<{ number: number; inEquation: boolean }>
  >(() => {
    const tempNumbers = [];
    let lowerHalf = false;
    let upperHalf = false;
    while (tempNumbers.length < 4) {
      const newNumber = Math.floor(Math.random() * 9) + 1;
      if (newNumber >= 1 && newNumber <= 4) lowerHalf = true;
      if (newNumber >= 6 && newNumber <= 9) upperHalf = true;
      if (tempNumbers.filter((num) => num.number === newNumber).length < 2) {
        tempNumbers.push({ number: newNumber, inEquation: false });
      }
      if (tempNumbers.length === 4 && (!lowerHalf || !upperHalf)) {
        tempNumbers.pop();
        lowerHalf = false;
        upperHalf = false;
      }
    }
    return tempNumbers;
  });
  const [operators, setOperators] = useState<
    Array<{ operator: string; inEquation: boolean }>
  >(() => {
    const operators = ["+", "−", "×", "÷"];
    const shuffledOperators = operators.sort(() => Math.random() - 0.5);
    const [firstOperator, secondOperator, thirdOperator] = shuffledOperators;
    return [
      { operator: firstOperator, inEquation: false },
      { operator: secondOperator, inEquation: false },
      { operator: thirdOperator, inEquation: false },
    ];
  });

  const handleNumberClick = (number: number, index: number) => {
    const newNumbers = [...numbers];
    newNumbers[index].inEquation = true;
    newNumbers.splice(index, 1);
    const newEquation = [...equation];
    const firstEmptySpot = newEquation.findIndex(
      (spot, index) => spot === null && index % 2 === 0
    );
    if (firstEmptySpot !== -1) {
      newEquation[firstEmptySpot] = number;
      setEquation(newEquation);
    }
    setNumbers(newNumbers);
  };

  const handleOperatorClick = (operator: string, index: number) => {
    const newOperators = [...operators];
    newOperators[index].inEquation = true;
    newOperators.splice(index, 1);
    const newEquation = [...equation];
    const firstEmptySpot = newEquation.findIndex(
      (spot, index) => spot === null && index % 2 === 1
    );
    if (firstEmptySpot !== -1) {
      newEquation[firstEmptySpot] = operator;
      setEquation(newEquation);
    }
    setOperators(newOperators);
  };

  const handleNumberEnable = (number: number, index: number) => {
    console.log(`Enabling number: ${number} at index: ${index}`);
    setNumbers((prevNumbers) => [
      ...prevNumbers,
      { number, inEquation: false },
    ]);
  };

  const handleOperatorEnable = (operator: string, index: number) => {
    console.log(`Enabling operator: ${operator} at index: ${index}`);
    setOperators((prevOperators) => [
      ...prevOperators,
      { operator, inEquation: false },
    ]);
  };

  const handleSymbolClick = (symbol: string | number, index: number) => {
    console.log(`Clicked symbol: ${symbol} at index: ${index}`);
    console.log("type of symbol is");
    console.log(typeof symbol);
    if (typeof symbol === "number") {
      console.log(`attempting to enable ${symbol} at index: ${index}`);
      handleNumberEnable(symbol, index);
    } else {
      console.log(`attempting to enable ${symbol} at index: ${index}`);
      handleOperatorEnable(symbol, index);
    }
    setEquation((prevEquation) => {
      const newEquation = [...prevEquation];
      newEquation[index] = null;
      return newEquation;
    });
  };

  const handleEquationSubmit = (time: number) => {
    console.log("in handleEquationSubmit");
    console.log("equation", equation);

    // Extract just the operators and numbers from the equation
    const operatorList = equation.filter(
      (item): item is string => typeof item === "string"
    );
    const numberList = equation.filter(
      (item): item is number => typeof item === "number"
    );

    console.log("RANK", calculateRank(operatorList, numberList));

    // Get today's date
    // Adjusting for timezone offset to get midnight west coast USA time

    // Update currentStreak and longestStreak
    // Adjusting for timezone offset to get yesterday's date at midnight west coast USA time
    const yesterday = new Date(
      new Date().getTime() - (864e5 + offset * 60 * 1000)
    )
      .toISOString()
      .split("T")[0];

    if (lastPlayedDate === yesterday || lastPlayedDate === null) {
      setCurrentStreak(currentStreak + 1);
      if (currentStreak + 1 > longestStreak) {
        setLongestStreak(currentStreak + 1);
      }
    } else if (lastPlayedDate !== yesterday) {
      setCurrentStreak(0);
    }

    // Update lastPlayedDate and totalDaysPlayed
    setLastPlayedDate(today);
    setTotalDaysPlayed(totalDaysPlayed + 1);

    // Calculate the rank of the submitted equation
    const ranks = calculateRank(operatorList, numberList);
    console.log("RANKS!!!", ranks);

    // Find the rank of the submitted equation
    const rankObject = ranks.find(
      (rank) => JSON.stringify(rank.equation) === JSON.stringify(equation)
    );
    console.log("RANKO BJECT:", rankObject);
    const rank = rankObject ? rankObject.rank : 0;
    const newBestResults = [
      ...bestResults,
      {
        date: today,
        time: currentTime,
        rank: rank,
      },
    ]
      .sort((a, b) => a.rank - b.rank || a.time - b.time)
      .slice(0, 3);
    setBestResults(newBestResults);
    let rankWithSuffixString = "";
    if (rank === 1) {
      rankWithSuffixString = "Best";
    } else if (rank === 2) {
      rankWithSuffixString = "2nd best";
    } else if (rank === 3) {
      rankWithSuffixString = "3rd best";
    } else if ((rank > 3 && rank <= 20) || rank % 100 > 20) {
      rankWithSuffixString = `${rank}th best`;
    } else if (rank % 10 === 1) {
      rankWithSuffixString = `${rank}st best`;
    } else if (rank % 10 === 2) {
      rankWithSuffixString = `${rank}nd best`;
    } else if (rank % 10 === 3) {
      rankWithSuffixString = `${rank}rd best`;
    } else {
      rankWithSuffixString = `${rank}th best`;
    }
    const hours = Math.floor(currentTime / 3600);
    const minutes = Math.floor((currentTime % 3600) / 60);
    const seconds = currentTime % 60;
    let timeString = "";
    if (hours > 0) timeString += `${hours}h `;
    if (minutes > 0) timeString += `${minutes}m `;
    if (seconds > 0) timeString += `${seconds}s`;
    timeString = timeString.trim();
    setShareObject({
      rank,
      rankWithSuffixString,
      timeString,
      equation,
    });
    setEquationSubmitted(true);
  };

  const handleClear = () => {
    equation.forEach((symbol, index) => {
      // If the symbol is not null, handle its click
      if (symbol !== null) {
        handleSymbolClick(symbol, index);
      }
    });
  };

  // Run on Game load and whenever any of them change
  useEffect(() => {
    saveState("currentStreak", currentStreak);
    saveState("lastPlayedDate", lastPlayedDate);
    saveState("bestResults", bestResults);
    saveState("totalDaysPlayed", totalDaysPlayed);
    saveState("longestStreak", longestStreak);
    saveState("shareObject", shareObject);
  }, [
    currentStreak,
    lastPlayedDate,
    bestResults,
    totalDaysPlayed,
    longestStreak,
    shareObject,
  ]);

  return (
    <Box>
      {equationSubmitted || lastPlayedDate === today ? (
        <>
          <EndScreen
            gameNumber={1} // replace with the appropriate state or value
            shareObject={shareObject}
            result={evaluation || 0}
          />
          <Footer />
        </>
      ) : (
        <>
          <TwentyOneDisplay evaluation={evaluation} />
          <Equation
            equation={equation}
            evaluation={evaluation}
            setEvaluation={setEvaluation}
            handleSymbolClick={handleSymbolClick}
          />
          <Box>
            {evaluation !== null ? (
              <Box sx={{ display: "flex", justifyContent: "center" }} mt={2}>
                <ClearButton onClear={handleClear} />
                <SubmitButton
                  onSubmit={() => handleEquationSubmit(currentTime)}
                  currentTime={currentTime}
                />{" "}
              </Box>
            ) : (
              <>
                <Operators
                  operators={operators}
                  onOperatorClick={handleOperatorClick}
                />
                <Numbers numbers={numbers} onNumberClick={handleNumberClick} />
                <ClearButton onClear={handleClear} />
              </>
            )}
          </Box>
          <Footer />
        </>
      )}
    </Box>
  );
};

export default Game;
