/** @format */

import "./App.css";
import React, { useState } from "react";
import Header from "./components/Header/Header.tsx";
import Game from "./components/Game/Game.tsx";

function App() {
  const [currentTime, setCurrentTime] = useState(0);

  return (
    <div className="App">
      <Header currentTime={currentTime} setCurrentTime={setCurrentTime} />
      <Game currentTime={currentTime} />
    </div>
  );
}

export default App;
